package com.guapi.webwork5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webwork4Application {

    public static void main(String[] args) {
        SpringApplication.run(Webwork4Application.class, args);
    }

}
