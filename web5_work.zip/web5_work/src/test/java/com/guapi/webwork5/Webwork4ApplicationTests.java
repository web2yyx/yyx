package com.guapi.webwork5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webwork4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
